# COMP-426-Project
This project was made for the COMP 426 final project at UNC by four students:
Meghana Ganapathiraju, Jennifer Li, Addy Liu, and Rachel Yuan.
Test Quest is a game based off of the classic Super Mario Bros., in which the user is a college student
who has overslept on the day of an exam. The objective of the game is to make it to their exam room before time runs out
to avoid failing the class. The user will first select a difficulty level, which will determine how long they have to find
and get to their exam room. On the way, they can eat food to accumulate points, and must dodge monsters to avoid losing points.
If they get to their exam room before time is up, they will be awarded bonus points based on how much time they had left
to spare. Once they get to their exam room, the quest is complete and the game is over; a leaderboard will pop up to show
their results. If they failed to get to their exam on time, an alternate screen will pop up to tell them they failed their
class. They will have the option to play again under both scenarios.
